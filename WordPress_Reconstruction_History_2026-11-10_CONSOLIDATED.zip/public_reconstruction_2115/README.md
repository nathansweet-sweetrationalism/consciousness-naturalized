# WordPress reconstruction record for article #2115

Authorized for public release by Nathan Sweet on 2026-11-10.

This package preserves the complete lossless WordPress historical reconstruction assembled during the article's November 2026 audit. The `11_Revisions` JSON contains eleven WordPress revisions plus the live post at the extraction point. `REVISION_12_DELTA` preserves the subsequent twelfth revision and changes to the live post. Source JSON files retain their original metadata and wording (including historical `private` flags); this archive is now public by explicit author instruction.

The source article, publication history and excerpts are Nathan Sweet's authored material. An archived passage is historical evidence of what the article said, not a current endorsement of its empirical or philosophical claims. Latest canonical reading edition: https://sweetrationalism.com/articles/consciousness/consciousness-naturalized-a-falsifiable-substrate-agnostic-consciousness-theory-ai-biology/

Contents:

- `Consciousness_Naturalized_2115_PRIVATE_WordPress_11_Revisions_2026-11-10.json`: lossless reconstruction of the exported post and 11 preceding revisions.
- `Consciousness_Naturalized_2115_PRIVATE_REVISION_12_DELTA_2026-11-10.json`: the additional post revision and export delta.
- `Consciousness_Naturalized_2115_HISTORICAL_BASE_2026-11-10.html`: extracted initial historical HTML for readable comparison.
- `Consciousness_Naturalized_2115_CURRENT_WP_BASE_2026-11-10.html`: readback before the final link and metadata amendments.
- `SHA256SUMS.txt`: SHA-256 of these four payload files, independently verifiable.

This archive deliberately does not include unreleased source-verification working notes, private conversations, third-party PDFs, passwords or credentials. The 11-revision export and twelfth-revision delta are complementary, not two independent experiments or scientific replications.

To verify, in the archive directory run `sha256sum -c SHA256SUMS.txt` on a system providing GNU coreutils.
